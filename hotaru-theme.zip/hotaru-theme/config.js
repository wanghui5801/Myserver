window.__PRE_CONFIG__ = {
  header: 'Server Status',
  subHeader: 'Servers\' Probes Set up with ServerStatus',
  interval: 1.5,
  footer: ''
};
